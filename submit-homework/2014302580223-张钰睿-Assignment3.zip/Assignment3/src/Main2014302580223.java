import java.util.ArrayList;

/**
 * Created by sakamichi on 2015/11/7.
 * Assignment3
 */
public class Main2014302580223 {

    public static void main(String[] args) throws Exception {
        ArrayList<String> HTMLList;
        String homepage = "http://www.wpi.edu/academics/cs/research-interests.html";
        HTMLList =  Gethtml2014302580223.Gethtml(homepage);
        long thread = Thread2014302580223.Test.Thread(1,HTMLList);//单线程
        long MultiThread = Thread2014302580223.Test.Thread(5,HTMLList);//五个线程
        System.out.println("多线程比单线程快"+(thread-MultiThread)+"毫秒");
        Mysql2014302580223.CreateTable();//建表
        for(int i = 0;i<Gethtml2014302580223.Linklist.size();i++){
           Mysql2014302580223.Mysql(JSoup2014302580223.names[i],JSoup2014302580223.emails[i],JSoup2014302580223.briefs[i]);
        }
    }
}
