import java.sql.*;

/**
 * Created by sakamichi on 2015/11/7.
 * Create a table to store the information
 */

public class Mysql2014302580223 {
    private static int result;
    private static Statement stmt;
    private static String sql;
    //private static int count = 0;

    public static void CreateTable()throws Exception{
        String url = "jdbc:mysql://localhost:3306/teacher?"
                + "user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
        Class.forName("com.mysql.jdbc.Driver");
        System.out.println("成功加载MySQL驱动程序");
        Connection conn = DriverManager.getConnection(url);
        stmt = conn.createStatement();
        sql = "create table 2014302580223_professor_info(name varchar(100),email varchar(100),brief varchar(10000),primary key(name))";
        result = stmt.executeUpdate(sql);
        System.out.println("创建数据表成功");
    }

    public static void Mysql(String name_, String email_, String brief_) throws Exception {
        try {
            if (result != -1) {
                sql = "select * from 2014302580223_professor_info where name='" + name_ + "'";
                ResultSet rs = stmt.executeQuery(sql);
                if (!rs.next()) {
                    sql = "insert into 2014302580223_professor_info(name,email,brief) values('" + name_ + "','" + email_ + "','" + brief_ + "')";
                    stmt.executeUpdate(sql);
                    //System.out.println("push"+count);
                    //count++;
                }
            }
        }catch (SQLException e) {
            System.out.println("MySQL操作错误");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
