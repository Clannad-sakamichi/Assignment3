import java.util.Objects;
import java.util.concurrent.*;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

/**
 * Created by sakamichi on 2015/11/7.
 * 多线程
 */

public class Thread2014302580223 {
    private static ArrayList<String> HTML;
    private static int average;
    private static String TaskSize;
    private static int mod;
    private static int count = 0;

    @SuppressWarnings("unchecked")
    public static class Test {
        public static long Thread(int taskSize,ArrayList<String> Linklist) throws ExecutionException,
                InterruptedException {
            System.out.println("----程序开始运行----");
            HTML = Linklist;
            TaskSize = "" + taskSize;//下面要用String型的tasksize作比较
            average = HTML.size() / taskSize;//分割Linklist
            count -=average;
            mod = HTML.size() % taskSize;//求余

            Date date1 = new Date();
            ExecutorService pool = Executors.newFixedThreadPool(taskSize);
            List<Future> list = new ArrayList<>();
            for (int i = 0; i < taskSize; i++) {
                Callable c = new MyCallable(i + " ");
                Future f = pool.submit(c);
                list.add(f);
            }
            pool.shutdown();

            //获取所有并发任务的运行结果
            for (Future f : list) {
                // 从Future对象上获取任务的返回值，并输出到控制台
                System.out.println(">>>" + f.get().toString());
            }
            Date date2 = new Date();
            System.out.println("----程序结束运行----，程序运行时间【"
                    + (date2.getTime() - date1.getTime()) + "毫秒】");
            count = 0;//回复初值
            JSoup2014302580223.count = 0;
            return (date2.getTime() - date1.getTime());
        }
    }

    static class MyCallable implements Callable<Object> {
        private String taskNum;

        MyCallable(String taskNum) {
            this.taskNum = taskNum;
        }

        public Object call() throws Exception {
            System.out.println(">>>" + taskNum + "任务启动");
            Date dateTmp1 = new Date();
            if(Objects.equals(taskNum + 1, TaskSize)){
                average += mod;
            }
            count +=average;
            int total = count+average;
            int temp = count;
            for (int i =temp;i <total;i++) {
                JSoup2014302580223.Read(HTML.get(i));
                //System.out.println("get"+i);
            }
            Date dateTmp2 = new Date();
            long time = dateTmp2.getTime() - dateTmp1.getTime();
            System.out.println(">>>" + taskNum + "任务终止");
            return taskNum + "任务返回运行结果,当前任务时间【" + time + "毫秒】";
        }
    }
}
