import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sakamichi on 2015/11/7.
 * get html we need from the home page
 */

public class Gethtml2014302580223 {
    public static ArrayList<String> Linklist = new ArrayList<>();
    public static ArrayList<String> Gethtml(String homepage) throws IOException {
        Document doc = Jsoup.connect(homepage).get();
        Elements eles=doc.select(".half a");
        for(Element e :eles) {
            Linklist.add(e.attr("href"));
        }
        return Linklist;
    }
}
