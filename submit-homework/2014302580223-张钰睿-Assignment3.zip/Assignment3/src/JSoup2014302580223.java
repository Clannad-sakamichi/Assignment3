import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 * Created by sakamichi on 2015/11/7.
 * use JSoup to analyze the html and select the information we need
 */

public class JSoup2014302580223 {
    public static String[] names = new String[Gethtml2014302580223.Linklist.size()];
    public static String[] emails = new String[Gethtml2014302580223.Linklist.size()];
    public static String[] briefs = new String[Gethtml2014302580223.Linklist.size()];
    public static int count = 0;

    public static void Read(String html) throws Exception {
        Document doc = Jsoup.connect(html).get();
        //名字
        String name = doc.select("h2").first().text();
        //简介
        String brief = doc.select(".titles").first().text();
        //email
        String email=doc.getElementById("contactinfo").getElementsByTag("a").first().text();

        names[count] = name;
        emails[count] = email;
        briefs[count] = brief;
        //System.out.println("get"+count);
        count++;
    }
}
